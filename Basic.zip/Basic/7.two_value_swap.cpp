#include<stdio.h>
int main()
{
	int a,b,temp;
	printf("Enter two numbers\n");
	scanf("%d\n%d",&a,&b);
	printf("The value before swapped is %d\t%d\n",a,b);
	//temp=a;
	//a=b;
	//b=temp;
	a=a+b;
	b=a-b;
	a=a-b;
	printf("The value after swapped is %d\t%d\n",a,b);
}