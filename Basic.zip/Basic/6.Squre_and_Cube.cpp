#include<stdio.h>
int main()
{
	int n;
	printf("Enter the Number\t");
	scanf("%d",&n);
	printf("The squre of %d is %d\nThe cube of %d is %d\n",n,(n*n),(n*n*n));
}