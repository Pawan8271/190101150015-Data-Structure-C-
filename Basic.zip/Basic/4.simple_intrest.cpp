#include<stdio.h>
int main()
{
	float p,r;
	int n;
	printf("enter the principle value\t");
	scanf("%f",&p);
	printf("enter no of year\t");
	scanf("%d",&n);
	printf("enter rate of intrest\t");
	scanf("%f",&r);
	printf("the simple intrest\t%f",(p*n*r)/100);
}