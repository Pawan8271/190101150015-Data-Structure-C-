#include<stdio.h>
int main()
{
	int n;
	printf("Enter the number\t");
	scanf("%d",&n);
	if(n>0)
	{
		printf("The Number is positive\n");
	}else if (n==0)
	{
		printf("The Number is zero\n");
	}
	else
	    printf("The number is negative\n");
}
