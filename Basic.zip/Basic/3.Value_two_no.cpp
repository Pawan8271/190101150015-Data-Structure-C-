#include<stdio.h>
int main()
{
	int a,b;
	printf("Enter two values\n");
	scanf("%d\n%d",&a,&b);
	printf("The sum is \t%d",a+b);
}