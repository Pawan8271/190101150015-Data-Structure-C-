#include<stdio.h>
int main()
{
	int a=5,b=8;
	printf("%d",a+b);
}