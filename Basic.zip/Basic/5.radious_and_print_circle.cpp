#include<stdio.h>
int main()
{
	int r;
	printf("Enter the radious of the Circle\t");
	scanf("%d",&r);
	printf("The area of a circle\t%f",(3.14*r*r));
}